<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/scss/style.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/LineIcons.2.0.css">
</head>
<body>
    <footer>
        <div class="wrapper">
            <div class="wrapper_logo">
                <img src="<?php echo get_template_directory_uri();?>/images/logo/logo.svg" alt="logo">
                    <p>
                    Lorem ipsum dolor sit amet, consetetur sadipscing
                     elitr, sed dinonumy eirmod tempor invidunt.
                    </p>
            </div>
            <div class="wrapper_links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Features</a></li>
                    <li><a href="#">Pricing</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <div class="wrapper_services">
                <h3>Services</h3>
                <ul>
                    <li><a href="#">SaaS Focused</a></li>
                    <li><a href="#">Awesome Designs</a></li>
                    <li><a href="#">Ready To Use</a></li>
                    <li><a href="#">Essentials Section</a></li>
                </ul>
            </div>
            <div class="wrapper_social">
                <h3>Follow On</h3>
                    <ul>
                        <li><a href="#"><i class="lni lni-facebook"></i></a></li>
                        <li><a href="#"><i class="lni lni-linkedin"></i></a></li>
                        <li><a href="#"><i class="lni lni-instagram"></i></a></li>
                        <li><a href="#"><i class="lni lni-twitter"></i></a></li>
                    </ul>
            </div>
        </div>
    </footer>
</body>
</html>