<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redesign Apps</title>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/scss/style.css">
</head>
<body>
    <header>
        <div class="wrapper">
            <div class="wrapper_logo"><img src="<?php echo get_template_directory_uri();?>/images/logo/logo.svg" alt="logo"></div>
                <div class="wrapper_icon" onclick="toggleBtn()">&#9776;</div>
                    <div class="wrapper_links">
                        <ul>
                            <li><a href="Home">Home</a></li>
                            <li><a href="features">Features</a></li>
                            <li><a href="pricing">Pricing</a></li>
                            <li><a href="team">Team</a></li>
                            <li><a href="testimonial">Testimonial</a></li>
                            <li><a href="download">Donwload</a></li>
                        </ul>
                    </div>
        </div>
    </header>
    <script src="<?php echo get_template_directory_uri();?>/js/script.js"></script>
</body>
</html>