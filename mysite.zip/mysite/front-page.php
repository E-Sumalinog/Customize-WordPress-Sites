<?php 
/* Template Name: Home */
get_header();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/scss/style.css">
</head>
<body>
    <main>
        <div class="hero">
            <div class="hero_title">
                <h2>I am using a free 
                    template version</h2>
                    <p>Please, purchase full versions of the template to get all sections,
                        elements and permissions to remove the credits.
                    </p>
                    <button>Purchase Now</button>
            </div>
            <div class="hero_img">
                <img src="<?php echo get_template_directory_uri();?>/images/hero/hero-image.svg" alt="hero">
            </div>
        </div>
        <div class="wrapper">
            <h3>Modern Design
                with Essentials Features
            </h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                Accusantium quisquam, sint cumque dolor sed quaerat corrupti cupiditate doloribus.</p>
                    <div class="wrapper_flex">
                        <div class="wrapper_flex1">
                            <h4>SaSS Focused</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                                    Asperiores quibusdam tenetur quae quos odio culpa!</p>
                        </div>
                        <div class="wrapper_flex2">
                            <h4>Awesome Design</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                                    Asperiores quibusdam tenetur quae quos odio culpa!</p>
                        </div>
                        <div class="wrapper_flex3">
                            <h4>Ready to Use</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                                    Asperiores quibusdam tenetur quae quos odio culpa!</p>
                        </div>
                    </div>
                    <div class="wrapper_flex">
                        <div class="wrapper_flex1">
                            <h4>Essentials Section</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                                    Asperiores quibusdam tenetur quae quos odio culpa!</p>
                        </div>
                        <div class="wrapper_flex2">
                            <h4>Well Organized Layer</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                                    Asperiores quibusdam tenetur quae quos odio culpa!</p>
                        </div>
                        <div class="wrapper_flex3">
                            <h4>Easily to Manage</h4>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. 
                                    Asperiores quibusdam tenetur quae quos odio culpa!</p>
                        </div>
                    </div>
        </div>
        <div class="solutions">
            <div class="solutions_img"><img src="<?php echo get_template_directory_uri();?>/images/feature/feature-image-1.svg" alt="feature"></div>
                <div class="solutions_desc">
                    <h3>Perfect Solutions Thriving Online
                        Business
                    </h3>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere,
                         consequatur impedit quam nihil alias a eligendi odit natus quia 
                         quibusdam recusandae aut repellendus ratione corporis animi voluptate 
                         nostrum dignissimos. Sequi aspernatur repudiandae.
                    </p>
                    <button>Read More</button>
                </div>
        </div>
    </main>

    <?php get_footer();?>
</body>
</html>